#include <iostream>
#include <iomanip>
#include "AirGeadBanking.h"
using namespace std;

int main()
{
    float initInvest, monDep, annualInt, numYears, numMonths;//declare variables
    float totalAmount, interestAmount, totInt;


    cout << "*******************\n";
    cout << "****DATA INPUT*****\n";
    cout << "Initial Investment Amount: $ ";        // Data input steps lines 14-40 
    cin >> initInvest;
    while (!(initInvest >= 0 ))      // loop to only allow positive numbers lines after each input
    {              
        std::cout << "Try Again.  Enter a positive number: ";
        std::cin >> initInvest;
    }  
    cout << "Monthly Deposit: $ ";
    cin >> monDep;
    while (!(monDep >= 0))
    {
        std::cout << "Try Again.  Enter a positive number: ";
        std::cin >> monDep;
    }
    cout << "Annual Interest: % ";
    cin >> annualInt;
    while (!(annualInt >= 0))
    {
        std::cout << "Try Again.  Enter a positive number: ";
        std::cin >> annualInt;
    }
    cout << "Number of Years: ";
    cin >> numYears;
    while (!(numYears >= 0))
    {
        std::cout << "Try Again.  Enter a positive number: ";
        std::cin >> numYears;
    }
    numMonths = numYears * 12;   // formula needed for getting interest with monthly deposits
    cout << "*******************\n";
    system("PAUSE");
    totalAmount = initInvest;
    cout << "\n\n\n\tBalance and Interest Without Additional Deposits\n";//start of report without deposit
    cout << "==============================================================\n";
    cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
    cout << "--------------------------------------------------------------\n";

    for (int i = 0; i < numYears; i++)
    {
        interestAmount = (totalAmount) * ((annualInt / 100));    // formula for interest amount report
        totalAmount = totalAmount + interestAmount;                // formula for total amount in report
        cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << interestAmount << "\n"; //output in report
    }
    totalAmount = initInvest;
    cout << "\n\n\n\tBalance and Interest With Additional Monthly Deposits\n";   // start of report with deposit
    cout << "==============================================================\n";
    cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
    cout << "--------------------------------------------------------------\n";
    for (int i = 0; i < numYears; i++)   // builds the lines based from amount of years in report
    {
        totInt = 0;
        for (int j = 0; j < 12; j++)
        {
            interestAmount = (totalAmount + monDep) * ((annualInt / 100) / 12);   // formula with deposit  for interest amount
            totInt = totInt + interestAmount;    // total interest formula
            totalAmount = totalAmount + monDep + interestAmount;  // total amount formula with deposit
        }
        cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAmount << "\t\t\t$" << totInt << "\n";   // output of formula with deposits
    }
    return 0;
}